

<?php $__env->startSection('title', 'Dashboard do Técnico'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mb-4">
        <h2>Dashboard do Técnico</h2>
        <p>Bem-vindo, <?php echo e(Auth::user()->nome); ?>!</p>
    </div>

    <!-- Card de Acesso Rápido -->
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Ordens de Serviço</h5>
                <p class="card-text">Gerencie as ordens de serviço atribuídas a você.</p>
                <a href="<?php echo e(route('ordens-servico.index')); ?>" class="btn btn-primary">
                    <i class="fas fa-clipboard-list"></i> Acessar
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Ordens de Serviço Ativas -->
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Minhas Ordens de Serviço Ativas</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Viatura</th>
                                <th>Cliente</th>
                                <th>Data</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = App\Models\OrdemServico::with(['viatura', 'viatura.cliente'])
                                ->where('mecanico_id', Auth::id())
                                ->where('status', '!=', 'Concluído')
                                ->latest()
                                ->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ordem->id); ?></td>
                                <td><?php echo e($ordem->viatura->marca); ?> <?php echo e($ordem->viatura->modelo); ?></td>
                                <td><?php echo e($ordem->viatura->cliente->nome); ?></td>
                                <td><?php echo e(date('d/m/Y', strtotime($ordem->data_servico))); ?></td>
                                <td>
                                    <span class="badge bg-warning"><?php echo e($ordem->status); ?></span>
                                </td>
                                <td>
                                    <a href="/ordens-servico/<?php echo e($ordem->id); ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="/ordens-servico/<?php echo e($ordem->id); ?>/edit" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\OfficinaAPP\OfficinaAPI\resources\views/dashboards/tecnico.blade.php ENDPATH**/ ?>