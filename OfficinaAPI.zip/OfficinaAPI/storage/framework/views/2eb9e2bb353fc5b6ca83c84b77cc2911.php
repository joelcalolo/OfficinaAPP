

<?php $__env->startSection('title', 'Meu Perfil'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <h2 class="mb-0">Meu Perfil</h2>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('perfil.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" class="form-control" id="nome" name="nome" value="<?php echo e(Auth::user()->nome); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e(Auth::user()->email); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="senha_atual" class="form-label">Senha Atual</label>
                        <input type="password" class="form-control" id="senha_atual" name="senha_atual">
                        <small class="text-muted">Deixe em branco se não quiser alterar a senha</small>
                    </div>

                    <div class="mb-3">
                        <label for="nova_senha" class="form-label">Nova Senha</label>
                        <input type="password" class="form-control" id="nova_senha" name="nova_senha">
                    </div>

                    <div class="mb-3">
                        <label for="confirmar_senha" class="form-label">Confirmar Nova Senha</label>
                        <input type="password" class="form-control" id="confirmar_senha" name="confirmar_senha">
                    </div>

                    <?php if(Auth::user()->role == 'cliente'): ?>
                    <div class="mb-3">
                        <label for="documento" class="form-label">Documento</label>
                        <input type="text" class="form-control" id="documento" name="documento" value="<?php echo e(Auth::user()->documento); ?>">
                    </div>
                    <?php endif; ?>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Salvar Alterações
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <?php if(Auth::user()->role == 'cliente'): ?>
        <div class="card mt-4">
            <div class="card-header bg-danger text-white">
                <h3 class="mb-0">Excluir Conta</h3>
            </div>
            <div class="card-body">
                <p class="text-danger">
                    <i class="fas fa-exclamation-triangle"></i> 
                    <strong>Atenção:</strong> A exclusão da conta é permanente e não pode ser desfeita.
                </p>
                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">
                    <i class="fas fa-trash"></i> Excluir Minha Conta
                </button>
            </div>
        </div>

        <!-- Modal de Confirmação de Exclusão -->
        <div class="modal fade" id="deleteAccountModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Confirmar Exclusão de Conta</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form action="<?php echo e(route('perfil.destroy')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-body">
                            <p class="text-danger">
                                <i class="fas fa-exclamation-triangle"></i>
                                <strong>Atenção:</strong> Esta ação é irreversível!
                            </p>
                            <p>Para confirmar a exclusão da sua conta, digite sua senha atual:</p>
                            <div class="mb-3">
                                <label for="senha_confirmacao" class="form-label">Senha</label>
                                <input type="password" class="form-control" id="senha_confirmacao" name="senha_confirmacao" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-trash"></i> Excluir Conta
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if(Auth::user()->role == 'cliente'): ?>
        <div class="card mt-4">
            <div class="card-header">
                <h3 class="mb-0">Minhas Viaturas</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Marca/Modelo</th>
                                <th>Estado</th>
                                <th>Última Atualização</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = Auth::user()->veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($viatura->marca); ?> <?php echo e($viatura->modelo); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($viatura->estado == 'Concluído' ? 'success' : 'warning'); ?>">
                                        <?php echo e($viatura->estado); ?>

                                    </span>
                                </td>
                                <td><?php echo e($viatura->updated_at->format('d/m/Y H:i')); ?></td>
                                <td>
                                    <a href="/viaturas/<?php echo e($viatura->id); ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> Detalhes
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\OfficinaAPP\OfficinaAPI\resources\views/perfil/index.blade.php ENDPATH**/ ?>