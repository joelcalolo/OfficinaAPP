<?php $__env->startSection('title', 'Viaturas'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Viaturas</h1>
    <a href="/viaturas/create" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nova Viatura
    </a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Cor</th>
                        <th>Estado</th>
                        <th>Cliente</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $viaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($viatura->id); ?></td>
                        <td><?php echo e($viatura->marca); ?></td>
                        <td><?php echo e($viatura->modelo); ?></td>
                        <td><?php echo e($viatura->cor); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($viatura->estado == 'Concluído' ? 'success' : 'warning'); ?>">
                                <?php echo e($viatura->estado); ?>

                            </span>
                        </td>
                        <td><?php echo e($viatura->cliente->nome); ?></td>
                        <td>
                            <a href="/viaturas/<?php echo e($viatura->id); ?>" class="btn btn-sm btn-info">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="/viaturas/<?php echo e($viatura->id); ?>/edit" class="btn btn-sm btn-warning">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($viatura->id); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__currentLoopData = $viaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal de Exclusão -->
<div class="modal fade" id="deleteModal<?php echo e($viatura->id); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmar Exclusão</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                Tem certeza que deseja excluir a viatura <?php echo e($viatura->marca); ?> <?php echo e($viatura->modelo); ?>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form action="/viaturas/<?php echo e($viatura->id); ?>" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Excluir</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\OfficinaAPP\OfficinaAPI\resources\views/viaturas/index.blade.php ENDPATH**/ ?>