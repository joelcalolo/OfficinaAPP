

<?php $__env->startSection('title', 'Minhas Viaturas'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mb-4">
        <h2>Minhas Viaturas</h2>
        <p>Bem-vindo, <?php echo e(Auth::user()->nome); ?>!</p>
    </div>

    <!-- Lista de Viaturas do Cliente -->
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Minhas Viaturas em Manutenção</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Marca/Modelo</th>
                                <th>Estado</th>
                                <th>Última Atualização</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = Auth::user()->veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($viatura->marca); ?> <?php echo e($viatura->modelo); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($viatura->estado == 'Concluído' ? 'success' : 'warning'); ?>">
                                        <?php echo e($viatura->estado); ?>

                                    </span>
                                </td>
                                <td><?php echo e($viatura->updated_at->format('d/m/Y H:i')); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#detalhesModal<?php echo e($viatura->id); ?>">
                                        <i class="fas fa-eye"></i> Detalhes
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">Nenhuma viatura encontrada.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Histórico de Serviços -->
    <div class="col-md-12 mt-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Histórico de Serviços</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Viatura</th>
                                <th>Serviço</th>
                                <th>Valor</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $hasServices = false; ?>
                            <?php $__currentLoopData = Auth::user()->veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $viatura->ordensServico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $ordem->servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $hasServices = true; ?>
                                        <tr>
                                            <td><?php echo e(date('d/m/Y', strtotime($ordem->data_servico))); ?></td>
                                            <td><?php echo e($viatura->marca); ?> <?php echo e($viatura->modelo); ?></td>
                                            <td><?php echo e($servico->servico->nome); ?></td>
                                            <td>R$ <?php echo e(number_format($servico->preco_unitario * $servico->quantidade, 2, ',', '.')); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo e($ordem->status == 'Concluído' ? 'success' : 'warning'); ?>">
                                                    <?php echo e($ordem->status ?? $viatura->estado); ?>

                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$hasServices): ?>
                                <tr>
                                    <td colspan="5" class="text-center">Nenhum serviço encontrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modais de Detalhes -->
<?php $__currentLoopData = Auth::user()->veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="detalhesModal<?php echo e($viatura->id); ?>" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detalhes da Viatura</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <!-- Informações da Viatura -->
                <div class="card mb-3">
                    <div class="card-header">
                        <h6 class="mb-0">Informações do Veículo</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Marca:</strong> <?php echo e($viatura->marca); ?></p>
                                <p><strong>Modelo:</strong> <?php echo e($viatura->modelo); ?></p>
                                <p><strong>Cor:</strong> <?php echo e($viatura->cor); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Estado:</strong> 
                                    <span class="badge bg-<?php echo e($viatura->estado == 'Concluído' ? 'success' : 'warning'); ?>">
                                        <?php echo e($viatura->estado); ?>

                                    </span>
                                </p>
                                <p><strong>Tipo de Avaria:</strong> <?php echo e($viatura->tipo_avaria); ?></p>
                                <p><strong>Código de Validação:</strong> <?php echo e($viatura->codigo_validacao); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Ordens de Serviço -->
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">Ordens de Serviço</h6>
                    </div>
                    <div class="card-body">
                        <?php if($viatura->ordensServico->count() > 0): ?>
                            <?php $__currentLoopData = $viatura->ordensServico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="border-bottom mb-3 pb-3">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <h6>Ordem #<?php echo e($ordem->id); ?> - <?php echo e(date('d/m/Y', strtotime($ordem->data_servico))); ?></h6>
                                        <span class="badge bg-<?php echo e($ordem->status == 'Concluído' ? 'success' : 'warning'); ?>">
                                            <?php echo e($ordem->status); ?>

                                        </span>
                                    </div>
                                    <p><strong>Mecânico:</strong> <?php echo e($ordem->mecanico->nome); ?></p>
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Serviço</th>
                                                <th>Quantidade</th>
                                                <th>Preço Unit.</th>
                                                <th>Subtotal</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $ordem->servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($servico->servico->nome); ?></td>
                                                    <td><?php echo e($servico->quantidade); ?></td>
                                                    <td>R$ <?php echo e(number_format($servico->preco_unitario, 2, ',', '.')); ?></td>
                                                    <td>R$ <?php echo e(number_format($servico->quantidade * $servico->preco_unitario, 2, ',', '.')); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th colspan="3" class="text-end">Total:</th>
                                                <th>R$ <?php echo e(number_format($ordem->total, 2, ',', '.')); ?></th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="text-center mb-0">Nenhuma ordem de serviço encontrada.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\OfficinaAPP\OfficinaAPI\resources\views/dashboards/cliente.blade.php ENDPATH**/ ?>