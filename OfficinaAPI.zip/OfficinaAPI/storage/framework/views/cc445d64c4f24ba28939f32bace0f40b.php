

<?php $__env->startSection('title', 'Ordens de Serviço'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Ordens de Serviço</h1>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addOrdemModal">
        <i class="fas fa-plus"></i> Nova Ordem de Serviço
    </button>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Viatura</th>
                        <th>Cliente</th>
                        <th>Mecânico</th>
                        <th>Data</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ordensServico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($ordem->id); ?></td>
                        <td><?php echo e($ordem->viatura->marca); ?> <?php echo e($ordem->viatura->modelo); ?></td>
                        <td><?php echo e($ordem->viatura->cliente->nome); ?></td>
                        <td><?php echo e($ordem->mecanico->nome); ?></td>
                        <td><?php echo e(date('d/m/Y', strtotime($ordem->data_servico))); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($ordem->status == 'Concluído' ? 'success' : 'warning'); ?>">
                                <?php echo e($ordem->status); ?>

                            </span>
                        </td>
                        <td>R$ <?php echo e(number_format($ordem->total, 2, ',', '.')); ?></td>
                        <td>
                            <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewOrdemModal<?php echo e($ordem->id); ?>">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editOrdemModal<?php echo e($ordem->id); ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteOrdemModal<?php echo e($ordem->id); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Adicionar Ordem de Serviço -->
<div class="modal fade" id="addOrdemModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Nova Ordem de Serviço</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('ordens-servico.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="viatura_id" class="form-label">Viatura</label>
                            <select class="form-select" id="viatura_id" name="viatura_id" required>
                                <?php $__currentLoopData = $viaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($viatura->id); ?>">
                                        <?php echo e($viatura->marca); ?> <?php echo e($viatura->modelo); ?> - <?php echo e($viatura->cliente->nome); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="mecanico_id" class="form-label">Mecânico</label>
                            <select class="form-select" id="mecanico_id" name="mecanico_id" required>
                                <?php $__currentLoopData = $mecanicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mecanico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mecanico->id); ?>"><?php echo e($mecanico->nome); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Serviços</label>
                        <div id="servicos-container">
                            <div class="row mb-2 servico-item">
                                <div class="col-md-6">
                                    <select class="form-select" name="servicos[0][servico_id]" required>
                                        <?php $__currentLoopData = $servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($servico->id); ?>" data-preco="<?php echo e($servico->preco); ?>">
                                                <?php echo e($servico->nome); ?> - R$ <?php echo e(number_format($servico->preco, 2, ',', '.')); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <input type="number" class="form-control" name="servicos[0][quantidade]" placeholder="Quantidade" value="1" min="1" required>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-danger btn-sm remover-servico">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-secondary btn-sm mt-2" id="adicionar-servico">
                            <i class="fas fa-plus"></i> Adicionar Serviço
                        </button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__currentLoopData = $ordensServico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal Visualizar Ordem de Serviço -->
<div class="modal fade" id="viewOrdemModal<?php echo e($ordem->id); ?>" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detalhes da Ordem de Serviço</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6>Informações da Viatura</h6>
                        <p><strong>Marca/Modelo:</strong> <?php echo e($ordem->viatura->marca); ?> <?php echo e($ordem->viatura->modelo); ?></p>
                        <p><strong>Cliente:</strong> <?php echo e($ordem->viatura->cliente->nome); ?></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Informações do Serviço</h6>
                        <p><strong>Mecânico:</strong> <?php echo e($ordem->mecanico->nome); ?></p>
                        <p><strong>Data:</strong> <?php echo e(date('d/m/Y', strtotime($ordem->data_servico))); ?></p>
                        <p><strong>Status:</strong> <?php echo e($ordem->status); ?></p>
                    </div>
                </div>

                <h6>Serviços Realizados</h6>
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Serviço</th>
                            <th>Quantidade</th>
                            <th>Preço Unitário</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $ordem->servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($servico->servico->nome); ?></td>
                            <td><?php echo e($servico->quantidade); ?></td>
                            <td>R$ <?php echo e(number_format($servico->preco_unitario, 2, ',', '.')); ?></td>
                            <td>R$ <?php echo e(number_format($servico->quantidade * $servico->preco_unitario, 2, ',', '.')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3" class="text-end">Total:</th>
                            <th>R$ <?php echo e(number_format($ordem->total, 2, ',', '.')); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Editar Ordem de Serviço -->
<div class="modal fade" id="editOrdemModal<?php echo e($ordem->id); ?>" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Ordem de Serviço</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('ordens-servico.update', $ordem->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="Em Análise" <?php echo e($ordem->status == 'Em Análise' ? 'selected' : ''); ?>>Em Análise</option>
                                <option value="Em Andamento" <?php echo e($ordem->status == 'Em Andamento' ? 'selected' : ''); ?>>Em Andamento</option>
                                <option value="Concluído" <?php echo e($ordem->status == 'Concluído' ? 'selected' : ''); ?>>Concluído</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="mecanico_id" class="form-label">Mecânico</label>
                            <select class="form-select" id="mecanico_id" name="mecanico_id" required>
                                <?php $__currentLoopData = $mecanicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mecanico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mecanico->id); ?>" <?php echo e($ordem->mecanico_id == $mecanico->id ? 'selected' : ''); ?>>
                                        <?php echo e($mecanico->nome); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Atualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Excluir Ordem de Serviço -->
<div class="modal fade" id="deleteOrdemModal<?php echo e($ordem->id); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmar Exclusão</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Tem certeza que deseja excluir esta ordem de serviço?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form action="<?php echo e(route('ordens-servico.destroy', $ordem->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Excluir</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
let servicoCount = 1;

document.getElementById('adicionar-servico').addEventListener('click', function() {
    const container = document.getElementById('servicos-container');
    const novoServico = document.createElement('div');
    novoServico.className = 'row mb-2 servico-item';
    novoServico.innerHTML = `
        <div class="col-md-6">
            <select class="form-select" name="servicos[${servicoCount}][servico_id]" required>
                <?php $__currentLoopData = $servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($servico->id); ?>" data-preco="<?php echo e($servico->preco); ?>">
                        <?php echo e($servico->nome); ?> - R$ <?php echo e(number_format($servico->preco, 2, ',', '.')); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-4">
            <input type="number" class="form-control" name="servicos[${servicoCount}][quantidade]" placeholder="Quantidade" value="1" min="1" required>
        </div>
        <div class="col-md-2">
            <button type="button" class="btn btn-danger btn-sm remover-servico">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    container.appendChild(novoServico);
    servicoCount++;
});

document.addEventListener('click', function(e) {
    if (e.target.classList.contains('remover-servico') || e.target.closest('.remover-servico')) {
        const servicoItem = e.target.closest('.servico-item');
        if (document.querySelectorAll('.servico-item').length > 1) {
            servicoItem.remove();
        }
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\OfficinaAPP\OfficinaAPI\resources\views/ordens-servico/index.blade.php ENDPATH**/ ?>