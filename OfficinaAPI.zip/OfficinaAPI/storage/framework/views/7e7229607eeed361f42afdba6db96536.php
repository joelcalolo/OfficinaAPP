

<?php $__env->startSection('title', 'Detalhes da Ordem de Serviço'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Detalhes da Ordem de Serviço #<?php echo e($ordem->id); ?></h2>
    </div>
    <div class="card-body">
        <div class="row mb-4">
            <div class="col-md-6">
                <h4>Informações da Viatura</h4>
                <table class="table table-sm">
                    <tr>
                        <th>Marca/Modelo:</th>
                        <td><?php echo e($ordem->viatura->marca); ?> <?php echo e($ordem->viatura->modelo); ?></td>
                    </tr>
                    <tr>
                        <th>Cliente:</th>
                        <td><?php echo e($ordem->viatura->cliente->nome); ?></td>
                    </tr>
                    <tr>
                        <th>Estado:</th>
                        <td>
                            <span class="badge bg-<?php echo e($ordem->status == 'Concluído' ? 'success' : 'warning'); ?>">
                                <?php echo e($ordem->status); ?>

                            </span>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <h4>Informações do Serviço</h4>
                <table class="table table-sm">
                    <tr>
                        <th>Data:</th>
                        <td><?php echo e(date('d/m/Y', strtotime($ordem->data_servico))); ?></td>
                    </tr>
                    <tr>
                        <th>Mecânico:</th>
                        <td><?php echo e($ordem->mecanico->nome); ?></td>
                    </tr>
                    <tr>
                        <th>Total:</th>
                        <td>R$ <?php echo e(number_format($ordem->total, 2, ',', '.')); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <h4>Serviços Realizados</h4>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Serviço</th>
                        <th>Quantidade</th>
                        <th>Preço Unitário</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ordem->servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($servico->servico->nome); ?></td>
                        <td><?php echo e($servico->quantidade); ?></td>
                        <td>R$ <?php echo e(number_format($servico->preco_unitario, 2, ',', '.')); ?></td>
                        <td>R$ <?php echo e(number_format($servico->quantidade * $servico->preco_unitario, 2, ',', '.')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="3" class="text-end">Total:</th>
                        <th>R$ <?php echo e(number_format($ordem->total, 2, ',', '.')); ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="d-flex justify-content-end mt-4">
            <a href="<?php echo e(route('ordens-servico.index')); ?>" class="btn btn-secondary me-2">Voltar</a>
            <?php if(in_array(Auth::user()->role, ['admin', 'secretario', 'gerente', 'tecnico'])): ?>
            <button type="button" class="btn btn-warning me-2" data-bs-toggle="modal" data-bs-target="#editStatusModal">
                <i class="fas fa-edit"></i> Atualizar Status
            </button>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if(in_array(Auth::user()->role, ['admin', 'secretario', 'gerente', 'tecnico'])): ?>
<!-- Modal Editar Status -->
<div class="modal fade" id="editStatusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Atualizar Status</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('ordens-servico.update', $ordem->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="Em Análise" <?php echo e($ordem->status == 'Em Análise' ? 'selected' : ''); ?>>Em Análise</option>
                            <option value="Em Andamento" <?php echo e($ordem->status == 'Em Andamento' ? 'selected' : ''); ?>>Em Andamento</option>
                            <option value="Concluído" <?php echo e($ordem->status == 'Concluído' ? 'selected' : ''); ?>>Concluído</option>
                        </select>
                    </div>
                    <input type="hidden" name="mecanico_id" value="<?php echo e($ordem->mecanico_id); ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Atualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\OfficinaAPP\OfficinaAPI\resources\views/ordens-servico/show.blade.php ENDPATH**/ ?>