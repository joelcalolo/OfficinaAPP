

<?php $__env->startSection('title', 'Gestão de Usuários'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Gestão de Usuários</h1>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
        <i class="fas fa-plus"></i> Novo Usuário
    </button>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Função</th>
                        <th>Documento</th>
                        <th>Data de Cadastro</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($usuario->nome); ?></td>
                        <td><?php echo e($usuario->email); ?></td>
                        <td><?php echo e(ucfirst($usuario->role)); ?></td>
                        <td>
                            <?php if($usuario->documento): ?>
                                <a href="<?php echo e(route('usuarios.download-documento', $usuario->id)); ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-download"></i> Download
                                </a>
                            <?php else: ?>
                                <span class="text-muted">Não enviado</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($usuario->created_at->format('d/m/Y')); ?></td>
                        <td>
                            <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewUserModal<?php echo e($usuario->id); ?>">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editUserModal<?php echo e($usuario->id); ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteUserModal<?php echo e($usuario->id); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Adicionar Usuário -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Novo Usuário</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('usuarios.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" class="form-control" id="nome" name="nome" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="senha" class="form-label">Senha</label>
                        <input type="password" class="form-control" id="senha" name="senha" required>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Função</label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="admin">Administrador</option>
                            <option value="secretario">Secretário</option>
                            <option value="tecnico">Técnico</option>
                            <option value="gerente">Gerente</option>
                            <option value="cliente">Cliente</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="documento" class="form-label">Documento de Identificação (PDF)</label>
                        <input type="file" class="form-control" id="documento" name="documento" accept=".pdf" required>
                        <small class="text-muted">Tamanho máximo: 2MB</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal Visualizar Usuário -->
<div class="modal fade" id="viewUserModal<?php echo e($usuario->id); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detalhes do Usuário</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p><strong>Nome:</strong> <?php echo e($usuario->nome); ?></p>
                <p><strong>Email:</strong> <?php echo e($usuario->email); ?></p>
                <p><strong>Função:</strong> <?php echo e(ucfirst($usuario->role)); ?></p>
                <p><strong>Data de Cadastro:</strong> <?php echo e($usuario->created_at->format('d/m/Y H:i')); ?></p>
                <p>
                    <strong>Documento:</strong>
                    <?php if($usuario->documento): ?>
                        <a href="<?php echo e(route('usuarios.download-documento', $usuario->id)); ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-download"></i> Download
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Não enviado</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Modal Editar Usuário -->
<div class="modal fade" id="editUserModal<?php echo e($usuario->id); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Usuário</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('usuarios.update', $usuario->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" class="form-control" id="nome" name="nome" value="<?php echo e($usuario->nome); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($usuario->email); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="senha" class="form-label">Nova Senha (deixe em branco para manter a atual)</label>
                        <input type="password" class="form-control" id="senha" name="senha">
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Função</label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="admin" <?php echo e($usuario->role == 'admin' ? 'selected' : ''); ?>>Administrador</option>
                            <option value="secretario" <?php echo e($usuario->role == 'secretario' ? 'selected' : ''); ?>>Secretário</option>
                            <option value="tecnico" <?php echo e($usuario->role == 'tecnico' ? 'selected' : ''); ?>>Técnico</option>
                            <option value="gerente" <?php echo e($usuario->role == 'gerente' ? 'selected' : ''); ?>>Gerente</option>
                            <option value="cliente" <?php echo e($usuario->role == 'cliente' ? 'selected' : ''); ?>>Cliente</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="documento" class="form-label">Documento de Identificação (PDF)</label>
                        <?php if($usuario->documento): ?>
                            <div class="mb-2">
                                <a href="<?php echo e(route('usuarios.download-documento', $usuario->id)); ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-download"></i> Download do documento atual
                                </a>
                            </div>
                        <?php endif; ?>
                        <input type="file" class="form-control" id="documento" name="documento" accept=".pdf">
                        <small class="text-muted">Tamanho máximo: 2MB. Deixe em branco para manter o documento atual.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Atualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Excluir Usuário -->
<div class="modal fade" id="deleteUserModal<?php echo e($usuario->id); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmar Exclusão</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Tem certeza que deseja excluir o usuário <?php echo e($usuario->nome); ?>?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form action="<?php echo e(route('usuarios.destroy', $usuario->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Excluir</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\OfficinaAPP\OfficinaAPI\resources\views/usuarios/index.blade.php ENDPATH**/ ?>